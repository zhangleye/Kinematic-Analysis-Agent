#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
结构示意图读取脚本：从桁架/刚架结构示意图中提取线段（杆件候选）与节点候选，
输出结构化 JSON 供 LLM 进行机动分析（计数 j/b/r -> 自由度 -> 组成分析）。

用法:
  python image_to_structure.py <图片路径> [--output out.json]
  python image_to_structure.py <图片路径> --verbose

流程:
  1. 灰度化 + 二值化（固定阈值滤浅色网格；0 时用 Otsu）
  2. 轮廓检测识别圆形节点标记 -> 记录圆心并从掩膜中挖除
  3. Zhang-Suen 细化，把粗杆件线变成 1px 骨架
  4. HoughLinesP 检测线段 -> 共线碎段合并
  5. 线段端点 + 圆心 统一聚类成候选节点
  6. 输出 JSON: nodes[], segments[]（两端节点 id、像素长度）与统计摘要

局限（务必向 LLM/用户说明）:
  - 提取的是"线段候选"，支座符号（三角形/链杆）、铰、虚线等语义需结合
    图像由 LLM 或用户确认，脚本不做语义判断。
  - 复杂背景/手绘图效果不理想，可调 --bin-threshold / --min-line-frac 等参数。
"""

import argparse
import json
import sys

import cv2
import numpy as np

# Windows 中文系统下 LocalShellBackend 以 GBK 读取子进程输出，
# 强制 stdout/stderr 输出 ASCII，任何编码读取端均兼容。
for _stream in (sys.stdout, sys.stderr):
    try:
        _stream.reconfigure(encoding="ascii", errors="backslashreplace")
    except Exception:
        pass


def _zhang_suen(img_bin01: np.ndarray, max_iter: int = 40) -> np.ndarray:
    """Zhang-Suen 细化。输入 0/1 二值图，输出 0/1 骨架。"""
    img = img_bin01.copy().astype(np.uint8)
    for _ in range(max_iter):
        changed = False
        for phase in (0, 1):
            to_del = []
            for y in range(1, img.shape[0] - 1):
                for x in range(1, img.shape[1] - 1):
                    if img[y, x] != 1:
                        continue
                    p = [img[y-1, x],   img[y-1, x+1], img[y, x+1], img[y+1, x+1],
                         img[y+1, x],   img[y+1, x-1], img[y, x-1], img[y-1, x-1]]
                    B = sum(p)
                    if B < 2 or B > 6:
                        continue
                    A = sum(1 for i in range(8) if p[i] == 0 and p[(i + 1) % 8] == 1)
                    if A != 1:
                        continue
                    if phase == 0:
                        if p[0] * p[2] * p[4] != 0 or p[2] * p[4] * p[6] != 0:
                            continue
                    else:
                        if p[0] * p[2] * p[6] != 0 or p[0] * p[4] * p[6] != 0:
                            continue
                    to_del.append((y, x))
            if to_del:
                changed = True
                for (y, x) in to_del:
                    img[y, x] = 0
        if not changed:
            break
    return img


def _detect_circle_nodes(bw: np.ndarray, short: int):
    """识别圆形节点标记，返回 [(cx, cy, r), ...]。"""
    contours, _ = cv2.findContours(bw, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    centers = []
    min_area = 12
    max_area = max(30, int(short * short * 0.012))
    for c in contours:
        area = cv2.contourArea(c)
        if area < min_area or area > max_area:
            continue
        peri = cv2.arcLength(c, True)
        if peri <= 0:
            continue
        circ = 4.0 * np.pi * area / (peri * peri)
        if circ < 0.55:
            continue
        (cx, cy), r = cv2.minEnclosingCircle(c)
        centers.append((int(cx), int(cy), int(r)))
    return centers


def _merge_collinear(segments, angle_tol=6.0, end_gap_frac=0.3):
    """合并共线且端点相近的碎段（处理杆件被交点切断的情况）。"""
    merged = list(segments)
    while True:
        changed = False
        for i in range(len(merged)):
            for j in range(i + 1, len(merged)):
                x1, y1, x2, y2 = merged[i]
                x3, y3, x4, y4 = merged[j]
                L1 = max(1, np.hypot(x2 - x1, y2 - y1))
                L2 = max(1, np.hypot(x4 - x3, y4 - y3))
                a1 = np.degrees(np.arctan2(y2 - y1, x2 - x1)) % 180
                a2 = np.degrees(np.arctan2(y4 - y3, x4 - x3)) % 180
                if min(abs(a1 - a2), 180 - abs(a1 - a2)) > angle_tol:
                    continue
                ends = [(x1, y1), (x2, y2), (x3, y3), (x4, y4)]
                min_d, pair = 1e18, None
                for p in range(2):
                    for q in range(2, 4):
                        d = np.hypot(ends[p][0] - ends[q][0], ends[p][1] - ends[q][1])
                        if d < min_d:
                            min_d, pair = d, (p, q)
                if min_d > max(L1, L2) * end_gap_frac:
                    continue
                # 取四个端点中最远的两点作为合并后线段
                d01 = np.hypot(x2 - x1, y2 - y1)
                d23 = np.hypot(x4 - x3, y4 - y3)
                far = max(
                    (np.hypot(ends[pair[0]][0] - ends[pair[1]][0],
                              ends[pair[0]][1] - ends[pair[1]][1]), pair[0], pair[1]),
                    (d01, 0, 1),
                    (d23, 2, 3),
                )
                _, pa, pb = far
                new_seg = (int(ends[pa][0]), int(ends[pa][1]),
                           int(ends[pb][0]), int(ends[pb][1]))
                merged[i] = new_seg
                del merged[j]
                changed = True
                break
            if changed:
                break
        if not changed:
            break
    return merged


def extract_structure(image_path: str, min_line_frac: float = 0.04,
                      max_line_gap: int = 12, hough_threshold: int = 30,
                      merge_dist_frac: float = 0.025,
                      bin_threshold: int = 120) -> dict:
    img = cv2.imread(image_path)
    if img is None:
        raise FileNotFoundError(f"无法读取图片: {image_path}")
    h, w = img.shape[:2]
    short = min(h, w)

    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    # 反色: 深色线条 -> 白色前景。bin_threshold>0 用固定阈值滤浅色网格；
    # =0 时用 Otsu。
    if bin_threshold and bin_threshold > 0:
        _, bw = cv2.threshold(gray, bin_threshold, 255, cv2.THRESH_BINARY_INV)
    else:
        _, bw = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)

    # 圆形节点标记：记录圆心并从掩膜中挖除（圆边切线不参与杆件检测）
    circle_nodes = _detect_circle_nodes(bw, short)
    for (cx, cy, r) in circle_nodes:
        cv2.circle(bw, (cx, cy), r + 3, 0, -1)

    # 细化 -> 1px 骨架
    skeleton = _zhang_suen(bw // 255) * 255
    skeleton = skeleton.astype(np.uint8)

    min_line_length = max(6, int(short * min_line_frac))
    lines = cv2.HoughLinesP(skeleton, rho=1, theta=np.pi / 180,
                            threshold=hough_threshold,
                            minLineLength=min_line_length,
                            maxLineGap=max_line_gap)
    segments = []
    if lines is not None:
        lines = np.asarray(lines).reshape(-1, 4)
        for x1, y1, x2, y2 in lines:
            segments.append((int(x1), int(y1), int(x2), int(y2)))

    segments = _merge_collinear(segments)

    # 端点 + 圆心 统一聚类成节点
    merge_dist = max(4, int(short * merge_dist_frac))
    points = [(cx, cy) for (cx, cy, r) in circle_nodes]
    for (x1, y1, x2, y2) in segments:
        points.append((x1, y1))
        points.append((x2, y2))

    nodes = []
    for p in points:
        found = False
        for n in nodes:
            if abs(n[0] - p[0]) <= merge_dist and abs(n[1] - p[1]) <= merge_dist:
                found = True
                break
        if not found:
            nodes.append(p)

    # 线段映射到节点 id（就近匹配）
    seg_out = []
    for (x1, y1, x2, y2) in segments:
        def nearest_id(px, py):
            best, bd = -1, 1e18
            for i, (nx, ny) in enumerate(nodes):
                d = (nx - px) ** 2 + (ny - py) ** 2
                if d < bd:
                    best, bd = i, d
            return best

        n1, n2 = nearest_id(x1, y1), nearest_id(x2, y2)
        length = int(np.hypot(x2 - x1, y2 - y1))
        seg_out.append({"from": n1, "to": n2, "length_px": length})

    return {
        "image_size": {"width": w, "height": h},
        "node_count": len(nodes),
        "segment_count": len(seg_out),
        "circle_nodes_detected": len(circle_nodes),
        "nodes": [{"id": i, "x": x, "y": y} for i, (x, y) in enumerate(nodes)],
        "segments": seg_out,
        "note": "线段/节点为候选，支座与铰的语义需结合图像人工或 LLM 确认",
    }


def main() -> None:
    p = argparse.ArgumentParser(description="从结构示意图提取线段与节点候选")
    p.add_argument("image", help="结构示意图路径 (png/jpg)")
    p.add_argument("--output", help="输出 JSON 文件路径（缺省则打印到 stdout）")
    p.add_argument("--min-line-frac", type=float, default=0.04,
                   help="最短线段 = 图像短边比例（默认 0.04）")
    p.add_argument("--max-line-gap", type=int, default=12, help="线段间隙容忍像素")
    p.add_argument("--threshold", type=int, default=30, help="霍夫累加器阈值，越大越严格")
    p.add_argument("--bin-threshold", type=int, default=120,
                   help="二值化固定阈值（灰度<=该值视为线条；0=自动Otsu）。"
                        "浅色网格背景建议 120-150，纯白底黑线图可设 0")
    p.add_argument("--merge-frac", type=float, default=0.025,
                   help="节点聚类距离 = 图像短边比例（默认 0.025）")
    p.add_argument("--verbose", action="store_true", help="同时输出提取预览图")
    args = p.parse_args()

    try:
        result = extract_structure(
            args.image, min_line_frac=args.min_line_frac,
            max_line_gap=args.max_line_gap, hough_threshold=args.threshold,
            merge_dist_frac=args.merge_frac, bin_threshold=args.bin_threshold,
        )
    except Exception as e:
        print(json.dumps({"error": str(e)}, ensure_ascii=True))
        sys.exit(1)

    out = json.dumps(result, ensure_ascii=True, indent=2)
    if args.output:
        with open(args.output, "w", encoding="utf-8") as f:
            f.write(out)
        print(f"written {args.output} | nodes {result['node_count']}, "
              f"segments {result['segment_count']}, "
              f"circle_nodes {result['circle_nodes_detected']}")
    else:
        print(out)

    if args.verbose:
        img = cv2.imread(args.image)
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        if args.bin_threshold and args.bin_threshold > 0:
            _, bw = cv2.threshold(gray, args.bin_threshold, 255, cv2.THRESH_BINARY_INV)
        else:
            _, bw = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)
        preview = cv2.cvtColor(bw, cv2.COLOR_GRAY2BGR)
        for s in result["segments"]:
            n1, n2 = result["nodes"][s["from"]], result["nodes"][s["to"]]
            cv2.line(preview, (n1["x"], n1["y"]), (n2["x"], n2["y"]),
                     (0, 0, 255), 2)
        for n in result["nodes"]:
            cv2.circle(preview, (n["x"], n["y"]), 3, (0, 255, 0), -1)
        cv2.imwrite(args.image + ".structure_preview.png", preview)
        print(f"preview saved: {args.image}.structure_preview.png")


if __name__ == "__main__":
    main()
