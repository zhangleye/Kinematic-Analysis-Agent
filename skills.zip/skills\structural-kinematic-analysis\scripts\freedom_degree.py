#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
结构力学机动分析 - 自由度计算与初判辅助脚本

用法:
  python freedom_degree.py truss --j 6 --b 8 --r 4     # 铰结桁架（节点法）
  python freedom_degree.py frame --m 2 --h 1 --r 3      # 一般平面体系（刚片法）

计数口径（务必先核对）:
  固定铰支座 = 2 根支座链杆；可动铰支座 = 1 根；固定端 = 3 根。
  复铰（n 根杆汇交）折算单铰数 = n - 1。

输出: W 值与初步判定。W = 0 或 W < 0 时须继续几何组成分析（见 SKILL.md）。
"""

import argparse
import sys

# Windows 中文系统下 LocalShellBackend 以 GBK 读取子进程输出，
# 强制 stdout/stderr 输出 ASCII，任何编码读取端均兼容。
for _stream in (sys.stdout, sys.stderr):
    try:
        _stream.reconfigure(encoding="ascii", errors="backslashreplace")
    except Exception:
        pass


def classify(w: int) -> None:
    print(f"W = {w}")
    if w > 0:
        print("Preliminary: W > 0 -> constraints insufficient, system is "
              "kinematically unstable (geometrically variable); done.")
    elif w == 0:
        print("Preliminary: W = 0 -> necessary condition satisfied, "
              "BUT must continue geometric composition analysis "
              "(binary-body / two-rigid-body / three-rigid-body rules) "
              "to rule out instantaneous instability and confirm no redundant "
              "constraints.")
    else:
        print(f"Preliminary: W < 0 -> constraints redundant "
              f"(redundant count >= {abs(w)}); must continue composition "
              "analysis and verify the exact redundant constraints one by one.")


def main() -> None:
    p = argparse.ArgumentParser(description="平面体系自由度计算与初判")
    p.add_argument(
        "kind",
        choices=["truss", "frame"],
        help="truss=铰结桁架(节点法)，frame=一般平面体系(刚片法)",
    )
    p.add_argument("--j", type=int, help="桁架: 节点数")
    p.add_argument("--b", type=int, help="桁架: 杆件数")
    p.add_argument("--m", type=int, help="刚片体系: 刚片数(不含基础)")
    p.add_argument("--h", type=int, help="刚片体系: 单铰数(复铰折算)")
    p.add_argument(
        "--r", type=int, help="支座链杆数(固定铰=2，可动铰=1，固定端=3)"
    )
    args = p.parse_args()

    if args.kind == "truss":
        if args.j is None or args.b is None or args.r is None:
            p.error("truss mode needs --j --b --r")
        w = 2 * args.j - args.b - args.r
        print(f"Truss nodal method: W = 2j - b - r = 2x{args.j} - {args.b} - {args.r}")
    else:
        if args.m is None or args.h is None or args.r is None:
            p.error("frame mode needs --m --h --r")
        w = 3 * args.m - 2 * args.h - args.r
        print(f"Rigid-body method: W = 3m - 2h - r = 3x{args.m} - 2x{args.h} - {args.r}")

    classify(w)


if __name__ == "__main__":
    main()
